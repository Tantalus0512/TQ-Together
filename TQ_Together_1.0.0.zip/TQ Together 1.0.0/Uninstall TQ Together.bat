@echo off
"%~dp0TQTogether.exe" --uninstall
